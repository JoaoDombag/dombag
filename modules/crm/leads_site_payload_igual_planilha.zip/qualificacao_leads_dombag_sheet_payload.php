<?php
declare(strict_types=1);
require_once $_SERVER['DOCUMENT_ROOT'].'/dombag/config/config.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/dombag/modules/login/auth.php';
require_once $_SERVER['DOCUMENT_ROOT'].'/dombag/modules/crm/leads_common.php';

$pdo = leadsPdo();
leadsEnsureSchema($pdo);

$isAjax = strtolower((string)($_SERVER['HTTP_X_REQUESTED_WITH'] ?? '')) === 'xmlhttprequest';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && $isAjax) {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $id       = (int)($_POST['id'] ?? 0);
        $status   = leadsNormalizeStatus((string)($_POST['status_atual'] ?? ''));
        $obs      = trim((string)($_POST['motivo_perda'] ?? ''));
        $vendedor = trim((string)($_POST['vendedor'] ?? ''));
        $valor    = trim((string)($_POST['valor_venda'] ?? ''));
        $valorDb  = $valor === '' ? null : (float)str_replace(',', '.', $valor);

        if ($id <= 0 || !isset(LEADS_STATUS_OPTIONS[$status])) {
            echo json_encode(['ok' => false, 'msg' => 'Dados inválidos.']);
            exit;
        }

        $sql = 'UPDATE leads_ads SET status_atual=:s, motivo_perda=:m, vendedor=:v, valor_venda=:vv, data_qualificacao=NOW()';
        if ($status === 'VENDA') {
            $sql .= ', data_venda_fechada = NOW()';
        }
        if ($status === 'PERDIDO' || $status === 'DESQUALIFICADO') {
            $sql .= ', data_perda = NOW()';
        }
        $sql .= ' WHERE id=:id';

        $pdo->prepare($sql)->execute([
            ':s'  => $status,
            ':m'  => $obs,
            ':v'  => $vendedor,
            ':vv' => $valorDb,
            ':id' => $id,
        ]);

        echo json_encode([
            'ok'           => true,
            'msg'          => 'Lead atualizado.',
            'status'       => $status,
            'status_label' => leadsStatusLabel($status),
        ]);
    } catch (Throwable $e) {
        echo json_encode(['ok' => false, 'msg' => $e->getMessage()]);
    }
    exit;
}

$f = [
    'status' => (string)($_GET['status'] ?? ''),
    'busca'  => trim((string)($_GET['busca'] ?? '')),
    'lp'     => trim((string)($_GET['lp'] ?? '')),
];

$where = [];
$params = [];
if ($f['status'] !== '' && isset(LEADS_STATUS_OPTIONS[leadsNormalizeStatus($f['status'])])) {
    $where[] = 'status_atual = :status';
    $params['status'] = leadsNormalizeStatus($f['status']);
}
if ($f['lp'] !== '') {
    $where[] = 'origem_lp = :lp';
    $params['lp'] = $f['lp'];
}
if ($f['busca'] !== '') {
    $where[] = '(nome LIKE :b OR telefone LIKE :b OR email LIKE :b OR empresa LIKE :b OR produto_interesse LIKE :b OR vendedor LIKE :b)';
    $params['b'] = '%'.$f['busca'].'%';
}

$sql = 'SELECT * FROM leads_ads';
if ($where) $sql .= ' WHERE '.implode(' AND ', $where);
$sql .= ' ORDER BY data_criacao DESC, id DESC LIMIT 300';
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$stats = leadsCountByStatus($pdo);
$lps = $pdo->query('SELECT origem_lp, COUNT(*) qtd FROM leads_ads GROUP BY origem_lp ORDER BY qtd DESC, origem_lp ASC')->fetchAll();

$statusMap = [
    'NOVO'              => ['class' => 'sl-novo',  'label' => 'Novo'],
    'EM_ANALISE'        => ['class' => 'sl-analise','label' => 'Em análise'],
    'QUALIFICADO'       => ['class' => 'sl-ok',    'label' => 'Qualificado'],
    'DESQUALIFICADO'    => ['class' => 'sl-desc',  'label' => 'Desqualificado'],
    'CLIENTE_EXISTENTE' => ['class' => 'sl-exist', 'label' => 'Cliente existente'],
    'DUPLICADO'         => ['class' => 'sl-dup',   'label' => 'Duplicado'],
    'VENDA'             => ['class' => 'sl-venda', 'label' => 'Venda'],
    'PERDIDO'           => ['class' => 'sl-desc',  'label' => 'Perdido'],
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Qualificação de Leads | DOMBAG</title>
<link rel="stylesheet" href="/dombag/public/css/unified_admin.css">
<style>
.sl-pill{display:inline-flex;align-items:center;gap:5px;padding:4px 10px;border-radius:999px;font-size:11px;font-weight:700;white-space:nowrap;}
.sl-novo{background:rgba(45,106,255,.1); color:#7db3ff;}.sl-analise{background:rgba(245,158,11,.1);color:var(--amber);}.sl-ok{background:rgba(0,201,167,.1); color:var(--teal);}.sl-desc{background:rgba(239,68,68,.1); color:var(--red);}.sl-exist{background:rgba(167,139,250,.1);color:var(--purple);}.sl-dup{background:rgba(255,255,255,.08);color:var(--text-muted);}.sl-venda{background:rgba(16,185,129,.12);color:#10b981;}
.filter-bar{display:grid;grid-template-columns:1fr 180px 180px auto;gap:10px;align-items:end;padding:16px 18px;border-bottom:1px solid var(--border);} @media(max-width:900px){.filter-bar{grid-template-columns:1fr 1fr;}} @media(max-width:600px){.filter-bar{grid-template-columns:1fr;}}
.leads-tbl{width:100%;border-collapse:collapse;}.leads-tbl th{padding:9px 14px;text-align:left;font-size:10px;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:var(--text-muted);border-bottom:1px solid var(--border);background:rgba(0,0,0,.1);white-space:nowrap;}.leads-tbl td{padding:11px 14px;font-size:12.5px;border-bottom:1px solid var(--border);vertical-align:top;}.leads-tbl tbody tr:hover td{background:rgba(255,255,255,.025);} .leads-tbl tbody tr.row-saving td{opacity:.6;}
.qual-cell{min-width:240px;}.qual-select{width:100%;height:34px;padding:0 8px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:7px;color:var(--text-primary);font-family:inherit;font-size:12.5px;cursor:pointer;outline:none;transition:border-color .15s;}.qual-obs,.qual-vend,.qual-valor{width:100%;margin-top:6px;min-height:38px;padding:6px 8px;background:rgba(255,255,255,.04);border:1px solid var(--border);border-radius:7px;color:var(--text-primary);font-family:inherit;font-size:12px;resize:none;outline:none;}.qual-obs{min-height:52px;}
.btn-qual{height:30px;padding:0 12px;font-size:12px;font-weight:600;border-radius:6px;border:none;cursor:pointer;background:var(--blue-accent);color:#fff;font-family:inherit;display:inline-flex;align-items:center;gap:5px;transition:background .15s;margin-top:6px;} .btn-qual:hover{background:var(--blue-light);} .btn-qual:disabled{opacity:.6;cursor:wait;}
.save-msg{font-size:11px;margin-top:4px;display:none;} .save-msg.ok{color:var(--teal);} .save-msg.err{color:var(--red);}
</style>
</head>
<body>
<div class="app-wrapper">
<?php include $_SERVER['DOCUMENT_ROOT'].'/dombag/shared/sidebar.php'; ?>
<div class="main">
<header class="topbar"><div class="topbar-left"><div class="page-title"><h1>Qualificação de Leads</h1><p>Leads recebidos da LP via webhook, no mesmo payload que antes ia para a planilha.</p></div></div></header>
<div class="content">
  <div class="kpi-strip" style="grid-template-columns:repeat(8,minmax(0,1fr));">
    <?php foreach (LEADS_STATUS_OPTIONS as $k=>$l): ?><div class="kpi-mini c-blue" style="flex-direction:column;align-items:flex-start;gap:4px;padding:11px 14px;"><div class="kpi-mini-val"><?= number_format($stats[$k] ?? 0,0,',','.') ?></div><div class="kpi-mini-lbl"><?= leadsH($l) ?></div></div><?php endforeach; ?>
  </div>
  <div class="panel" style="margin-bottom:20px;">
    <form method="GET"><div class="filter-bar">
      <div class="field"><label>Busca</label><input type="text" name="busca" value="<?= leadsH($f['busca']) ?>" placeholder="Nome, telefone, e-mail, empresa, produto ou vendedor…"></div>
      <div class="field"><label>Status</label><select name="status" class="filter-select"><option value="">Todos</option><?php foreach (LEADS_STATUS_OPTIONS as $k=>$l): ?><option value="<?= leadsH($k) ?>" <?= leadsNormalizeStatus($f['status'])===$k?'selected':'' ?>><?= leadsH($l) ?></option><?php endforeach; ?></select></div>
      <div class="field"><label>LP</label><select name="lp" class="filter-select"><option value="">Todas</option><?php foreach ($lps as $o): ?><option value="<?= leadsH((string)$o['origem_lp']) ?>" <?= $f['lp']===(string)$o['origem_lp']?'selected':'' ?>><?= leadsH((string)$o['origem_lp']) ?> (<?= (int)$o['qtd'] ?>)</option><?php endforeach; ?></select></div>
      <div style="display:flex;gap:8px;align-items:flex-end;"><button type="submit" class="btn-primary" style="height:36px;">Filtrar</button><a href="/dombag/modules/crm/qualificacao_leads.php" class="btn-secondary" style="height:36px;">Limpar</a></div>
    </div></form>
  </div>
  <div class="panel"><div style="padding:13px 18px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;gap:10px;"><span style="font-size:14px;font-weight:600;">Leads</span><span class="count-badge"><?= count($rows) ?></span></div>
    <?php if (empty($rows)): ?><div class="empty-state"><p>Nenhum lead encontrado.</p></div><?php else: ?><div style="overflow-x:auto;"><table class="leads-tbl"><thead><tr><th>#</th><th>Lead</th><th>Origem</th><th>Status atual</th><th>Qualificar</th></tr></thead><tbody>
    <?php foreach ($rows as $r): $st=(string)($r['status_atual']??'NOVO'); $sInfo=$statusMap[$st]??['class'=>'sl-novo','label'=>$st]; ?>
    <tr id="row-<?= (int)$r['id'] ?>">
      <td class="td-muted" style="font-size:11px;"><?= (int)$r['id'] ?><br><span style="font-size:10px;">lead_id: <?= leadsH((string)$r['lead_id']) ?: '—' ?></span></td>
      <td><div style="font-weight:700;font-size:13px;"><?= leadsH((string)$r['nome']) ?: '<span style="color:var(--text-muted)">Sem nome</span>' ?></div><?php if ($r['empresa']): ?><div class="td-muted"><?= leadsH((string)$r['empresa']) ?></div><?php endif; ?><div class="td-muted" style="font-size:11px;"><?= leadsH((string)$r['produto_interesse']) ?: '—' ?></div><?php if ($r['telefone']): ?><div style="margin-top:4px;"><?= leadsH(leadsPhoneForDisplay((string)$r['telefone'])) ?></div><?php endif; ?><?php if ($r['email']): ?><div class="td-muted"><?= leadsH((string)$r['email']) ?></div><?php endif; ?><div class="td-muted" style="font-size:10.5px;margin-top:3px;"><?= date('d/m/Y H:i', strtotime((string)$r['data_criacao'])) ?></div></td>
      <td><div style="font-weight:600;">LP: <?= leadsH((string)$r['origem_lp']) ?: '—' ?></div><div class="td-muted" style="font-size:11px;">Botão: <?= leadsH((string)$r['origem_botao']) ?: '—' ?></div><?php if ($r['utm_campaign']): ?><div class="td-muted" style="font-size:11px;">Campanha: <?= leadsH((string)$r['utm_campaign']) ?></div><?php endif; ?><?php if ($r['vendedor']): ?><div class="td-muted" style="font-size:11px;">Vendedor: <?= leadsH((string)$r['vendedor']) ?></div><?php endif; ?></td>
      <td id="status-cell-<?= (int)$r['id'] ?>"><span class="sl-pill <?= $sInfo['class'] ?>"><?= leadsH($sInfo['label']) ?></span><?php if ($r['motivo_perda']): ?><div class="td-muted" style="font-size:11px;margin-top:4px;max-width:160px;"><?= leadsH((string)$r['motivo_perda']) ?></div><?php endif; ?><?php if ($r['valor_venda']): ?><div class="td-muted" style="font-size:11px;margin-top:4px;">Valor: R$ <?= number_format((float)$r['valor_venda'],2,',','.') ?></div><?php endif; ?></td>
      <td class="qual-cell"><select class="qual-select" id="sel-<?= (int)$r['id'] ?>"><?php foreach (LEADS_STATUS_OPTIONS as $k=>$l): ?><option value="<?= leadsH($k) ?>" <?= $st===$k?'selected':'' ?>><?= leadsH($l) ?></option><?php endforeach; ?></select><input class="qual-vend" id="vend-<?= (int)$r['id'] ?>" placeholder="Vendedor" value="<?= leadsH((string)$r['vendedor']) ?>"><input class="qual-valor" id="valor-<?= (int)$r['id'] ?>" placeholder="Valor venda (ex.: 12500,00)" value="<?= $r['valor_venda'] !== null ? leadsH((string)$r['valor_venda']) : '' ?>"><textarea class="qual-obs" id="obs-<?= (int)$r['id'] ?>" placeholder="Observação / motivo perda…"><?= leadsH((string)$r['motivo_perda']) ?></textarea><button class="btn-qual" id="btn-<?= (int)$r['id'] ?>" onclick="salvarLead(<?= (int)$r['id'] ?>)">Salvar</button><div class="save-msg" id="msg-<?= (int)$r['id'] ?>"></div></td>
    </tr>
    <?php endforeach; ?></tbody></table></div><?php endif; ?>
  </div>
</div></div></div>
<script>
async function salvarLead(id){const btn=document.getElementById('btn-'+id),msg=document.getElementById('msg-'+id),sel=document.getElementById('sel-'+id),obs=document.getElementById('obs-'+id),vend=document.getElementById('vend-'+id),valor=document.getElementById('valor-'+id),row=document.getElementById('row-'+id);btn.disabled=true;btn.textContent='Salvando…';msg.style.display='none';row.classList.add('row-saving');const fd=new FormData();fd.append('id',id);fd.append('status_atual',sel.value);fd.append('motivo_perda',obs.value);fd.append('vendedor',vend.value);fd.append('valor_venda',valor.value);try{const res=await fetch(window.location.href,{method:'POST',headers:{'X-Requested-With':'XMLHttpRequest'},body:fd});const data=await res.json();if(data.ok){const cell=document.getElementById('status-cell-'+id);if(cell){const sClass={NOVO:'sl-novo',EM_ANALISE:'sl-analise',QUALIFICADO:'sl-ok',DESQUALIFICADO:'sl-desc',CLIENTE_EXISTENTE:'sl-exist',DUPLICADO:'sl-dup',VENDA:'sl-venda',PERDIDO:'sl-desc'}[data.status]||'sl-novo';let html=`<span class="sl-pill ${sClass}">${data.status_label}</span>`;if(obs.value.trim()) html += `<div class="td-muted" style="font-size:11px;margin-top:4px;max-width:160px;">${obs.value.trim()}</div>`;if(valor.value.trim()) html += `<div class="td-muted" style="font-size:11px;margin-top:4px;">Valor: R$ ${valor.value.trim()}</div>`;cell.innerHTML = html;}msg.className='save-msg ok';msg.textContent='✓ Salvo';} else {msg.className='save-msg err';msg.textContent='✗ '+(data.msg||'Erro');}}catch(e){msg.className='save-msg err';msg.textContent='✗ Falha na requisição';}msg.style.display='block';btn.disabled=false;btn.textContent='Salvar';row.classList.remove('row-saving');setTimeout(()=>{msg.style.display='none';},3000);}
</script>
</body></html>
